import os
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
NOTEBOOKS_DIR = PROJECT_ROOT / "notebooks"

# Data files
DATA_JSON_PATH = DATA_DIR / "data.json"
PROCESSED_DATA_PATH = DATA_DIR / "processed_data.json"
TRAIN_DATA_PATH = DATA_DIR / "train_data.json"
VAL_DATA_PATH = DATA_DIR / "val_data.json"

# Model paths
MODEL_SAVE_PATH = MODELS_DIR / "saved_model"
TOKENIZER_SAVE_PATH = MODELS_DIR / "tokenizer"

# NER Labels (BIO tagging scheme)
NER_LABELS = [
    'O',           # Outside any entity
    'B-CITY',      # Beginning of City
    'I-CITY',      # Inside City
    'B-DISTRICT',  # Beginning of District
    'I-DISTRICT',  # Inside District
    'B-STATE',     # Beginning of State
    'I-STATE',     # Inside State
    'B-PINCODE',   # Beginning of Pincode
    'B-PO_NAME',   # Beginning of Post Office Name
    'I-PO_NAME'    # Inside Post Office Name
]

# Label to ID mapping
LABEL_TO_ID = {label: i for i, label in enumerate(NER_LABELS)}
ID_TO_LABEL = {i: label for i, label in enumerate(NER_LABELS)}

# Model configuration
MODEL_CONFIG = {
    'model_name': 'bert-base-multilingual-cased',  # Can also use 'ai4bharat/indic-bert'
    'max_length': 128,
    'batch_size': 16,
    'learning_rate': 2e-5,
    'num_epochs': 10,
    'warmup_steps': 500,
    'weight_decay': 0.01,
    'dropout': 0.1
}

# Training configuration
TRAIN_CONFIG = {
    'test_size': 0.2,
    'val_size': 0.1,
    'random_state': 42,
    'stratify': True
}

# Validation thresholds
VALIDATION_CONFIG = {
    'similarity_threshold': 0.8,  # For fuzzy matching
    'max_distance': 2  # Maximum edit distance for corrections
}

# Common Indian address patterns
INDIAN_STATES = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
    'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
    'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya',
    'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim',
    'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand',
    'West Bengal', 'Delhi', 'Jammu and Kashmir', 'Ladakh', 'Puducherry',
    'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu',
    'Lakshadweep', 'Andaman and Nicobar Islands'
]

# Common address keywords for preprocessing
ADDRESS_KEYWORDS = {
    'pincode_indicators': ['pin', 'pincode', 'postal code', 'zip'],
    'post_office_indicators': ['po', 'post office', 'gpo', 'hpo'],
    'district_indicators': ['dist', 'district'],
    'state_indicators': ['state'],
    'city_indicators': ['city', 'town', 'village']
}