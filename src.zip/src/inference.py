import json
import re
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForTokenClassification
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

from config import *
from pincode_validation import PincodeValidator

class AddressNERInference:
    def __init__(self, model_path=None):
        self.model_path = model_path or MODEL_SAVE_PATH
        self.tokenizer = None
        self.model = None
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.validator = PincodeValidator()
        self.load_model()
    
    def load_model(self):
        """Load trained model and tokenizer."""
        print(f"Loading model from {self.model_path}")
        
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path)
            self.model = AutoModelForTokenClassification.from_pretrained(self.model_path)
            self.model.to(self.device)
            self.model.eval()
            print("Model loaded successfully!")
        except Exception as e:
            print(f"Error loading model: {e}")
            raise
    
    def preprocess_text(self, text: str) -> str:
        """Clean and preprocess input text."""
        if not text:
            return ""
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        
        # Handle common abbreviations
        abbreviations = {
            r'\bpo\b': 'post office',
            r'\bgpo\b': 'general post office', 
            r'\bhpo\b': 'head post office',
            r'\bdist\b': 'district',
            r'\bpin\b': 'pincode',
        }
        
        for abbrev, full_form in abbreviations.items():
            text = re.sub(abbrev, full_form, text, flags=re.IGNORECASE)
        
        return text
    
    def tokenize_and_predict(self, text: str) -> Tuple[List[str], List[str], List[float]]:
        """Tokenize text and make NER predictions."""
        # Preprocess and tokenize
        processed_text = self.preprocess_text(text)
        tokens = processed_text.split()
        
        if not tokens:
            return [], [], []
        
        # Tokenize for BERT
        encoding = self.tokenizer(
            tokens,
            is_split_into_words=True,
            padding='max_length',
            truncation=True,
            max_length=MODEL_CONFIG['max_length'],
            return_tensors='pt'
        )
        
        # Move to device
        input_ids = encoding['input_ids'].to(self.device)
        attention_mask = encoding['attention_mask'].to(self.device)
        
        # Predict
        with torch.no_grad():
            outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
            predictions = torch.nn.functional.softmax(outputs.logits, dim=-1)
            predicted_labels = torch.argmax(predictions, dim=-1)
        
        # Convert back to labels and align with original tokens
        word_ids = encoding.word_ids()
        predicted_labels = predicted_labels[0].cpu().numpy()
        predictions = predictions[0].cpu().numpy()
        
        # Align predictions with original tokens
        aligned_labels = []
        aligned_confidences = []
        previous_word_id = None
        
        for i, word_id in enumerate(word_ids):
            if word_id is not None and word_id != previous_word_id:
                if word_id < len(tokens):
                    label_id = predicted_labels[i]
                    label = ID_TO_LABEL[label_id]
                    confidence = np.max(predictions[i])
                    
                    aligned_labels.append(label)
                    aligned_confidences.append(confidence)
                
                previous_word_id = word_id
        
        # Ensure alignment
        if len(aligned_labels) > len(tokens):
            aligned_labels = aligned_labels[:len(tokens)]
            aligned_confidences = aligned_confidences[:len(tokens)]
        elif len(aligned_labels) < len(tokens):
            aligned_labels.extend(['O'] * (len(tokens) - len(aligned_labels)))
            aligned_confidences.extend([0.0] * (len(tokens) - len(aligned_confidences)))
        
        return tokens, aligned_labels, aligned_confidences
    
    def extract_entities(self, tokens: List[str], labels: List[str], confidences: List[float]) -> Dict[str, str]:
        """Extract entities from BIO-tagged tokens."""
        entities = {
            'PostOfficeName': '',
            'City': '',
            'District': '',
            'State': '',
            'Pincode': ''
        }
        
        # Entity mapping
        entity_map = {
            'PO_NAME': 'PostOfficeName',
            'CITY': 'City',
            'DISTRICT': 'District',
            'STATE': 'State',
            'PINCODE': 'Pincode'
        }
        
        current_entity = None
        current_tokens = []
        
        for token, label, confidence in zip(tokens, labels, confidences):
            if label == 'O':
                # End current entity if any
                if current_entity and current_tokens:
                    entity_key = entity_map.get(current_entity)
                    if entity_key:
                        entities[entity_key] = ' '.join(current_tokens)
                
                current_entity = None
                current_tokens = []
            
            elif label.startswith('B-'):
                # Start new entity
                if current_entity and current_tokens:
                    entity_key = entity_map.get(current_entity)
                    if entity_key:
                        entities[entity_key] = ' '.join(current_tokens)
                
                current_entity = label[2:]  # Remove 'B-'
                current_tokens = [token]
            
            elif label.startswith('I-') and current_entity:
                # Continue current entity
                entity_type = label[2:]  # Remove 'I-'
                if entity_type == current_entity:
                    current_tokens.append(token)
        
        # Handle last entity
        if current_entity and current_tokens:
            entity_key = entity_map.get(current_entity)
            if entity_key:
                entities[entity_key] = ' '.join(current_tokens)
        
        # Clean extracted entities
        for key, value in entities.items():
            if value:
                entities[key] = self.clean_extracted_entity(value, key)
        
        return entities
    
    def clean_extracted_entity(self, value: str, entity_type: str) -> str:
        """Clean and validate extracted entity values."""
        if not value:
            return ""
        
        # Remove extra spaces
        value = re.sub(r'\s+', ' ', value.strip())
        
        # Entity-specific cleaning
        if entity_type == 'Pincode':
            # Extract only digits for pincode
            pincode = re.findall(r'\d{6}', value)
            if pincode:
                return pincode[0]
            else:
                # Try to find any 6-digit sequence
                digits = re.sub(r'[^\d]', '', value)
                if len(digits) >= 6:
                    return digits[:6]
        
        elif entity_type in ['City', 'District', 'State', 'PostOfficeName']:
            # Clean location names
            value = re.sub(r'[^\w\s\-\.]', '', value)
            # Capitalize properly
            value = value.title()
        
        return value
    
    def post_process_entities(self, entities: Dict[str, str]) -> Dict[str, str]:
        """Post-process extracted entities for better accuracy."""
        processed = entities.copy()
        
        # Handle missing entities by checking for patterns in other fields
        text_parts = ' '.join([v for v in entities.values() if v]).lower()
        
        # Try to extract pincode from any field if missing
        if not processed['Pincode']:
            pincode_match = re.search(r'\b\d{6}\b', text_parts)
            if pincode_match:
                processed['Pincode'] = pincode_match.group()
        
        # Try to identify state if missing
        if not processed['State']:
            for state in INDIAN_STATES:
                if state.lower() in text_parts:
                    processed['State'] = state
                    break
        
        # Remove duplicates between fields
        for field1 in processed:
            for field2 in processed:
                if field1 != field2 and processed[field1] and processed[field2]:
                    if processed[field1].lower() in processed[field2].lower():
                        # Keep the longer, more specific one
                        if len(processed[field1]) < len(processed[field2]):
                            processed[field1] = ""
        
        return processed
    
    def predict(self, text: str, validate_pincode: bool = True) -> Dict:
        """Main prediction function."""
        if not text or not text.strip():
            return {
                'input_text': text,
                'entities': {},
                'validation': {'is_valid': False, 'message': 'Empty input'},
                'confidence': 0.0
            }
        
        try:
            # Make predictions
            tokens, labels, confidences = self.tokenize_and_predict(text)
            
            if not tokens:
                return {
                    'input_text': text,
                    'entities': {},
                    'validation': {'is_valid': False, 'message': 'No tokens found'},
                    'confidence': 0.0
                }
            
            # Extract entities
            entities = self.extract_entities(tokens, labels, confidences)
            entities = self.post_process_entities(entities)
            
            # Calculate overall confidence
            entity_confidences = []
            for i, label in enumerate(labels):
                if label != 'O' and i < len(confidences):
                    entity_confidences.append(confidences[i])
            
            overall_confidence = np.mean(entity_confidences) if entity_confidences else 0.0
            
            # Validate entities
            validation_result = {'is_valid': True, 'issues': [], 'suggestions': {}}
            
            if validate_pincode and entities.get('Pincode'):
                validation = self.validator.validate_consistency(entities)
                
                if not validation['is_consistent']:
                    validation_result = {
                        'is_valid': False,
                        'issues': validation['issues'],
                        'suggestions': validation.get('suggestions', {}),
                        'confidence_penalty': 1.0 - validation['confidence']
                    }
                    
                    # Apply confidence penalty
                    overall_confidence *= validation['confidence']
            
            # Build result
            result = {
                'input_text': text,
                'processed_text': self.preprocess_text(text),
                'tokens': tokens,
                'labels': labels,
                'entities': entities,
                'validation': validation_result,
                'confidence': float(overall_confidence),
                'debug_info': {
                    'token_confidences': [float(c) for c in confidences],
                    'entity_count': sum(1 for v in entities.values() if v)
                }
            }
            
            return result
            
        except Exception as e:
            return {
                'input_text': text,
                'entities': {},
                'validation': {'is_valid': False, 'message': f'Error: {str(e)}'},
                'confidence': 0.0,
                'error': str(e)
            }
    
    def predict_batch(self, texts: List[str]) -> List[Dict]:
        """Predict on a batch of texts."""
        results = []
        
        for text in texts:
            result = self.predict(text)
            results.append(result)
        
        return results
    
    def get_corrected_address(self, text: str) -> Dict:
        """Get address with automatic corrections applied."""
        result = self.predict(text)
        
        if result['validation']['is_valid']:
            return result
        
        # Try to correct using pincode validation
        entities = result['entities']
        if entities.get('Pincode'):
            corrected_entities = self.validator.correct_address(entities)
            
            # Create corrected result
            corrected_result = result.copy()
            corrected_result['entities'] = corrected_entities
            corrected_result['validation'] = {'is_valid': True, 'corrected': True}
            corrected_result['original_entities'] = entities
            
            return corrected_result
        
        return result
    
    def suggest_addresses(self, text: str, max_suggestions: int = 5) -> List[Dict]:
        """Suggest possible address completions/corrections."""
        result = self.predict(text)
        entities = result['entities']
        
        suggestions = []
        
        # Get pincode suggestions if we have location info
        if any(entities.get(field) for field in ['City', 'District', 'State']):
            pincode_suggestions = self.validator.suggest_pincode(entities)
            
            for suggestion in pincode_suggestions[:max_suggestions]:
                suggested_entities = entities.copy()
                suggested_entities.update({
                    'Pincode': suggestion['pincode'],
                    'PostOfficeName': suggestion['post_office'],
                    'City': suggestion['city'],
                    'District': suggestion['district'],
                    'State': suggestion['state']
                })
                
                suggestions.append({
                    'entities': suggested_entities,
                    'match_score': suggestion['match_score'],
                    'formatted_address': self.format_address(suggested_entities)
                })
        
        return suggestions
    
    def format_address(self, entities: Dict[str, str]) -> str:
        """Format entities into a readable address."""
        parts = []
        
        if entities.get('PostOfficeName'):
            parts.append(entities['PostOfficeName'])
        
        if entities.get('City'):
            parts.append(entities['City'])
        
        if entities.get('District') and entities.get('District') != entities.get('City'):
            parts.append(entities['District'])
        
        if entities.get('State'):
            parts.append(entities['State'])
        
        if entities.get('Pincode'):
            parts.append(entities['Pincode'])
        
        return ', '.join(parts)

# Command Line Interface
def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Address NER Inference')
    parser.add_argument('--text', type=str, help='Input address text')
    parser.add_argument('--file', type=str, help='Input file with addresses (one per line)')
    parser.add_argument('--output', type=str, help='Output JSON file')
    parser.add_argument('--no-validation', action='store_true', help='Disable pincode validation')
    parser.add_argument('--suggestions', action='store_true', help='Generate address suggestions')
    
    args = parser.parse_args()
    
    # Initialize inference engine
    print("Initializing Address NER Inference Engine...")
    predictor = AddressNERInference()
    
    results = []
    
    if args.text:
        # Single text prediction
        print(f"\nProcessing: {args.text}")
        result = predictor.predict(args.text, validate_pincode=not args.no_validation)
        
        print("\nExtracted Entities:")
        for entity, value in result['entities'].items():
            if value:
                print(f"  {entity}: {value}")
        
        print(f"\nConfidence: {result['confidence']:.3f}")
        print(f"Validation: {'✓' if result['validation']['is_valid'] else '✗'}")
        
        if not result['validation']['is_valid']:
            print(f"Issues: {result['validation']['issues']}")
        
        if args.suggestions:
            suggestions = predictor.suggest_addresses(args.text)
            if suggestions:
                print("\nAddress Suggestions:")
                for i, suggestion in enumerate(suggestions, 1):
                    print(f"  {i}. {suggestion['formatted_address']} (Score: {suggestion['match_score']:.3f})")
        
        results.append(result)
    
    elif args.file:
        # Batch prediction from file
        print(f"Processing addresses from: {args.file}")
        
        with open(args.file, 'r', encoding='utf-8') as f:
            addresses = [line.strip() for line in f if line.strip()]
        
        print(f"Found {len(addresses)} addresses")
        
        results = predictor.predict_batch(addresses)
        
        # Print summary
        valid_count = sum(1 for r in results if r['validation']['is_valid'])
        avg_confidence = np.mean([r['confidence'] for r in results])
        
        print(f"\nProcessing Summary:")
        print(f"  Total addresses: {len(results)}")
        print(f"  Valid addresses: {valid_count}")
        print(f"  Average confidence: {avg_confidence:.3f}")
    
    else:
        # Interactive mode
        print("\nInteractive Mode - Enter addresses (type 'quit' to exit):")
        
        while True:
            try:
                text = input("\nAddress: ").strip()
                if text.lower() in ['quit', 'exit', 'q']:
                    break
                
                if not text:
                    continue
                
                result = predictor.predict(text, validate_pincode=not args.no_validation)
                
                print("\nExtracted:")
                for entity, value in result['entities'].items():
                    if value:
                        print(f"  {entity}: {value}")
                
                print(f"Confidence: {result['confidence']:.3f}")
                print(f"Valid: {'✓' if result['validation']['is_valid'] else '✗'}")
                
                results.append(result)
                
            except KeyboardInterrupt:
                break
    
    # Save results if output file specified
    if args.output and results:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        print(f"\nResults saved to: {args.output}")

if __name__ == "__main__":
    main()