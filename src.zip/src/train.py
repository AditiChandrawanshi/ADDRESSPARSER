import json
import torch
import numpy as np
from transformers import (
    AutoTokenizer, 
    AutoModelForTokenClassification,
    AutoConfig,
    TrainingArguments,
    Trainer,
    DataCollatorForTokenClassification
)
from torch.utils.data import Dataset
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from seqeval.metrics import classification_report as ner_classification_report
from seqeval.metrics import f1_score as ner_f1_score
import warnings
warnings.filterwarnings('ignore')

from config import *

class AddressNERDataset(Dataset):
    def __init__(self, data, tokenizer, max_length=128):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        tokens = item['tokens']
        labels = item['labels']
        
        # Tokenize and align labels
        encoding = self.tokenizer(
            tokens,
            is_split_into_words=True,
            padding='max_length',
            truncation=True,
            max_length=self.max_length,
            return_tensors='pt'
        )
        
        # Align labels with tokenized input
        aligned_labels = self.align_labels_with_tokens(
            labels, encoding.word_ids()
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(aligned_labels, dtype=torch.long)
        }
    
    def align_labels_with_tokens(self, labels, word_ids):
        """Align labels with BERT tokens."""
        aligned_labels = []
        previous_word_id = None
        
        for word_id in word_ids:
            if word_id is None:
                # Special tokens get -100 (ignored in loss calculation)
                aligned_labels.append(-100)
            elif word_id != previous_word_id:
                # First token of a word gets the label
                if word_id < len(labels):
                    aligned_labels.append(LABEL_TO_ID[labels[word_id]])
                else:
                    aligned_labels.append(LABEL_TO_ID['O'])
            else:
                # Subsequent tokens of the same word get -100
                aligned_labels.append(-100)
            
            previous_word_id = word_id
        
        return aligned_labels

class AddressNERTrainer:
    def __init__(self, model_name=None):
        self.model_name = model_name or MODEL_CONFIG['model_name']
        self.tokenizer = None
        self.model = None
        self.trainer = None
        
    def setup_model_and_tokenizer(self):
        """Initialize tokenizer and model."""
        print(f"Loading tokenizer and model: {self.model_name}")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        
        # Add special tokens if needed
        special_tokens = ['[ADDRESS]', '[PINCODE]', '[LOCATION]']
        self.tokenizer.add_tokens(special_tokens)
        
        # Load and modify config to include dropout
        config = AutoConfig.from_pretrained(
            self.model_name,
            num_labels=len(NER_LABELS),
            label2id=LABEL_TO_ID,
            id2label=ID_TO_LABEL
        )
        
        # Set dropout in config (this is the correct way)
        if 'dropout' in MODEL_CONFIG:
            config.hidden_dropout_prob = MODEL_CONFIG['dropout']
            config.attention_probs_dropout_prob = MODEL_CONFIG['dropout']
        
        # Load model
        print("Creating model...")
        self.model = AutoModelForTokenClassification.from_pretrained(
            self.model_name,
            config=config
        )
        
        # Resize token embeddings if we added special tokens
        self.model.resize_token_embeddings(len(self.tokenizer))
        
        print(f"✅ Model loaded with {len(NER_LABELS)} labels")
        print(f"✅ Model type: {type(self.model)}")
        
        # Verify model is properly created
        if self.model is None:
            raise RuntimeError("❌ Model creation failed!")
        
        return self.model, self.tokenizer
        
    def load_datasets(self):
        """Load preprocessed datasets."""
        print("Loading datasets...")
        
        with open(TRAIN_DATA_PATH, 'r', encoding='utf-8') as f:
            train_data = json.load(f)
        
        with open(VAL_DATA_PATH, 'r', encoding='utf-8') as f:
            val_data = json.load(f)
        
        print(f"Loaded {len(train_data)} training samples")
        print(f"Loaded {len(val_data)} validation samples")
        
        return train_data, val_data
    
    def compute_metrics(self, eval_pred):
        """Compute evaluation metrics."""
        predictions, labels = eval_pred
        predictions = np.argmax(predictions, axis=2)
        
        # Remove ignored index (special token) predictions and labels
        true_predictions = [
            [ID_TO_LABEL[p] for (p, l) in zip(prediction, label) if l != -100]
            for prediction, label in zip(predictions, labels)
        ]
        true_labels = [
            [ID_TO_LABEL[l] for (p, l) in zip(prediction, label) if l != -100]
            for prediction, label in zip(predictions, labels)
        ]
        
        # Calculate NER-specific metrics
        f1 = ner_f1_score(true_labels, true_predictions)
        
        return {
            'f1': f1,
        }
    
    def train(self):
        """Train the NER model."""
        # ALWAYS setup model and tokenizer first
        self.setup_model_and_tokenizer()
        
        # Force GPU setup after model is loaded
        if torch.cuda.is_available():
            device = torch.device('cuda:0')
            torch.cuda.set_device(device)
            print(f"🎯 FORCING GPU: {torch.cuda.get_device_name()}")
            
            # Move model to GPU explicitly
            self.model = self.model.to(device)
            print(f"✅ Model on: {next(self.model.parameters()).device}")
        else:
            print("❌ NO GPU - Training will be very slow")
        
        # Load data
        train_data, val_data = self.load_datasets()
        
        # Create datasets
        train_dataset = AddressNERDataset(
            train_data, self.tokenizer, MODEL_CONFIG['max_length']
        )
        val_dataset = AddressNERDataset(
            val_data, self.tokenizer, MODEL_CONFIG['max_length']
        )
        
        # Setup training arguments
        training_args = TrainingArguments(
            output_dir=str(MODEL_SAVE_PATH),
            num_train_epochs=MODEL_CONFIG['num_epochs'],
            per_device_train_batch_size=MODEL_CONFIG['batch_size'],
            per_device_eval_batch_size=MODEL_CONFIG['batch_size'],
            warmup_steps=MODEL_CONFIG['warmup_steps'],
            weight_decay=MODEL_CONFIG['weight_decay'],
            learning_rate=MODEL_CONFIG['learning_rate'],
            logging_dir=str(MODEL_SAVE_PATH / 'logs'),
            logging_steps=100,
            eval_strategy="epoch",  # Changed from evaluation_strategy
            save_strategy="epoch",
            save_total_limit=2,
            load_best_model_at_end=True,
            metric_for_best_model="f1",
            report_to="none",  # Disable wandb/tensorboard
            # GPU optimizations
            fp16=torch.cuda.is_available(),  # Enable mixed precision for GPU
            dataloader_pin_memory=torch.cuda.is_available(),  # Enable for GPU
            dataloader_num_workers=2 if torch.cuda.is_available() else 0,  # Reduce for GPU
        )
        
        # Data collator
        data_collator = DataCollatorForTokenClassification(
            tokenizer=self.tokenizer, return_tensors="pt"
        )
        
        # Initialize trainer
        self.trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            data_collator=data_collator,
            compute_metrics=self.compute_metrics,
            tokenizer=self.tokenizer,
        )
        
        print("Starting training...")
        
        # Train the model
        train_result = self.trainer.train()
        
        # Save the model and tokenizer
        print("Saving model and tokenizer...")
        self.trainer.save_model()
        self.tokenizer.save_pretrained(MODEL_SAVE_PATH)
        
        # Print training results
        print(f"Training completed!")
        print(f"Training loss: {train_result.training_loss:.4f}")
        
        # Evaluate on validation set
        eval_results = self.trainer.evaluate()
        print(f"Validation F1: {eval_results['eval_f1']:.4f}")
        
        return train_result
    
    def evaluate_detailed(self, test_data_path=None):
        """Detailed evaluation with classification report."""
        if not test_data_path:
            test_data_path = DATA_DIR / "test_data.json"
        
        with open(test_data_path, 'r', encoding='utf-8') as f:
            test_data = json.load(f)
        
        test_dataset = AddressNERDataset(
            test_data, self.tokenizer, MODEL_CONFIG['max_length']
        )
        
        # Get predictions
        predictions = self.trainer.predict(test_dataset)
        pred_logits = predictions.predictions
        pred_labels = np.argmax(pred_logits, axis=2)
        true_labels = predictions.label_ids
        
        # Convert to label names
        true_predictions = [
            [ID_TO_LABEL[p] for (p, l) in zip(prediction, label) if l != -100]
            for prediction, label in zip(pred_labels, true_labels)
        ]
        true_labels_named = [
            [ID_TO_LABEL[l] for (p, l) in zip(prediction, label) if l != -100]
            for prediction, label in zip(pred_labels, true_labels)
        ]
        
        # Print detailed classification report
        print("\nDetailed Classification Report:")
        print(ner_classification_report(true_labels_named, true_predictions))
        
        return true_predictions, true_labels_named

if __name__ == "__main__":
    # Create model directory
    MODEL_SAVE_PATH.mkdir(parents=True, exist_ok=True)
    
    # Check if training data exists
    if not TRAIN_DATA_PATH.exists():
        print("Training data not found. Please run preprocessing first:")
        print("python src/preprocess.py")
        exit(1)
    
    # Initialize and train
    trainer = AddressNERTrainer()
    
    print("Starting Address NER Training...")
    print(f"Model: {MODEL_CONFIG['model_name']}")
    print(f"Labels: {NER_LABELS}")
    print("-" * 50)
    
    # Train the model
    train_result = trainer.train()
    
    # Detailed evaluation if test data exists
    if (DATA_DIR / "test_data.json").exists():
        print("\nRunning detailed evaluation...")
        trainer.evaluate_detailed()
    
    print("Training pipeline completed successfully!")