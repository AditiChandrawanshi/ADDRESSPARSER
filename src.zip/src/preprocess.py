import json
import random
import re
from typing import List, Dict, Tuple, Optional
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from config import *

class AddressDataPreprocessor:
    def __init__(self):
        self.data = []
        self.synthetic_patterns = [
            "{po_name}, {city}, {district}, {state} - {pincode}",
            "{city}, {district}, {state}, Pin: {pincode}",
            "{po_name}, {city}, Dist: {district}, {state} {pincode}",
            "{city}, {state} - {pincode}",
            "{po_name}, {district}, {state}",
            "{city} {pincode}, {state}",
            "{po_name}, {city}-{pincode}, {district}, {state}",
            "Near {po_name}, {city}, {state}",
            "{district} {city}, {state} {pincode}"
        ]
    
    def load_data(self, file_path: str) -> List[Dict]:
        """Load data from JSON file, handling UTF-8 BOM issues and different formats."""
        try:
            # First try with utf-8-sig encoding to handle BOM
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
            
            # Handle different data formats
            data = self._normalize_data_format(data)
            print(f"Loaded {len(data)} records from {file_path}")
            return data
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            print(f"Error with utf-8-sig encoding: {e}")
            try:
                # Fallback to regular utf-8
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Remove BOM if present
                    if content.startswith('\ufeff'):
                        content = content[1:]
                    data = json.loads(content)
                
                # Handle different data formats
                data = self._normalize_data_format(data)
                print(f"Loaded {len(data)} records from {file_path} (BOM removed)")
                return data
            except Exception as e2:
                print(f"Error loading data with utf-8 encoding: {e2}")
                try:
                    # Last resort: try reading as binary and decode
                    with open(file_path, 'rb') as f:
                        raw_data = f.read()
                        # Remove UTF-8 BOM bytes if present
                        if raw_data.startswith(b'\xef\xbb\xbf'):
                            raw_data = raw_data[3:]
                        content = raw_data.decode('utf-8')
                        data = json.loads(content)
                    
                    # Handle different data formats
                    data = self._normalize_data_format(data)
                    print(f"Loaded {len(data)} records from {file_path} (binary mode)")
                    return data
                except Exception as e3:
                    print(f"Final attempt failed: {e3}")
                    return []
        except Exception as e:
            print(f"Unexpected error loading data: {e}")
            return []
    
    def _normalize_data_format(self, data) -> List[Dict]:
        """Normalize different JSON data formats to a list of dictionaries."""
        # If data is already a list of dictionaries, return as is
        if isinstance(data, list) and all(isinstance(item, dict) for item in data):
            return data
        
        # If data is a dictionary, check if it contains sheet-like structures
        if isinstance(data, dict):
            # Common patterns for Excel exports: Sheet1, data, records, etc.
            possible_keys = ['Sheet1', 'data', 'records', 'items', 'Sheet 1', 'sheet1']
            
            for key in possible_keys:
                if key in data and isinstance(data[key], list):
                    print(f"Found data in '{key}' key")
                    return self._normalize_data_format(data[key])
            
            # If no sheet keys found, check if all values are lists
            list_values = [v for v in data.values() if isinstance(v, list)]
            if list_values:
                # Use the first list found (usually the main data)
                print(f"Found list data in dictionary, using first list with {len(list_values[0])} items")
                return self._normalize_data_format(list_values[0])
            
            # If it's a single record dictionary, wrap it in a list
            # Check if it has address-like fields
            address_fields = ['PostOfficeName', 'City', 'District', 'State', 'Pincode',
                             'post_office_name', 'city', 'district', 'state', 'pincode']
            if any(field in data for field in address_fields):
                return [data]
            
            # If no recognizable structure, return empty list
            print(f"Warning: Dictionary doesn't contain recognizable data structure. Keys: {list(data.keys())}")
            return []
        
        # If data is a list but contains strings or other types, try to handle it
        if isinstance(data, list):
            normalized = []
            for item in data:
                if isinstance(item, str):
                    # Try to parse string as JSON
                    try:
                        parsed_item = json.loads(item)
                        if isinstance(parsed_item, dict):
                            normalized.append(parsed_item)
                    except json.JSONDecodeError:
                        # If string is not JSON, skip or create a basic record
                        print(f"Warning: Skipping non-JSON string: {item[:50]}...")
                        continue
                elif isinstance(item, dict):
                    normalized.append(item)
                else:
                    print(f"Warning: Skipping unsupported data type: {type(item)}")
            return normalized
        
        # If data is a single string, try to parse it
        if isinstance(data, str):
            try:
                parsed_data = json.loads(data)
                return self._normalize_data_format(parsed_data)  # Recursively normalize
            except json.JSONDecodeError:
                print(f"Warning: Could not parse string as JSON: {data[:100]}...")
                return []
        
        # If none of the above, return empty list
        print(f"Warning: Unsupported data format: {type(data)}")
        return []
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text."""
        if not text:
            return ""
        
        # Remove extra spaces and normalize
        text = re.sub(r'\s+', ' ', text.strip())
        
        # Remove special characters but keep essential punctuation
        text = re.sub(r'[^\w\s\-.,()]', '', text)
        
        return text
    
    def generate_synthetic_addresses(self, records: List[Dict], num_samples_per_record: int = 3) -> List[str]:
        """Generate synthetic address strings from structured data."""
        synthetic_addresses = []
        
        # Debug: Print first few records to understand the format
        print(f"Processing {len(records)} records...")
        if records:
            print("Sample record structure:")
            sample_record = records[0]
            print(f"  Type: {type(sample_record)}")
            if isinstance(sample_record, dict):
                print(f"  Keys: {list(sample_record.keys())}")
            else:
                print(f"  Content: {sample_record}")
        
        for i, record in enumerate(records):
            if not isinstance(record, dict):
                print(f"Warning: Record {i} is not a dictionary: {type(record)}")
                continue
                
            # Try to extract address components with multiple possible field names
            field_mappings = {
                'PostOfficeName': ['PostOfficeName', 'post_office_name', 'po_name', 'postoffice', 'office_name'],
                'City': ['City', 'city', 'town', 'locality'],
                'District': ['District', 'district', 'dist'],
                'State': ['State', 'state', 'province'],
                'Pincode': ['Pincode', 'pincode', 'pin_code', 'postal_code', 'zip']
            }
            
            # Clean the record data with flexible field mapping
            clean_record = {}
            for standard_key, possible_keys in field_mappings.items():
                value = ''
                for key in possible_keys:
                    if key in record:
                        value = str(record[key])
                        break
                
                # Convert to expected format
                if standard_key == 'PostOfficeName':
                    clean_record['po_name'] = self.clean_text(value)
                elif standard_key == 'City':
                    clean_record['city'] = self.clean_text(value)
                elif standard_key == 'District':
                    clean_record['district'] = self.clean_text(value)
                elif standard_key == 'State':
                    clean_record['state'] = self.clean_text(value)
                elif standard_key == 'Pincode':
                    clean_record['pincode'] = str(value) if value else ''
            
            # Skip if no usable data found
            if not any(clean_record.values()):
                print(f"Warning: No usable address data found in record {i}: {record}")
                continue
            
            # Generate multiple variants per record
            for _ in range(num_samples_per_record):
                pattern = random.choice(self.synthetic_patterns)
                try:
                    # Sometimes skip certain fields to create realistic variations
                    working_record = clean_record.copy()
                    if not working_record['po_name'] or random.random() < 0.2:  # 20% chance to skip PO name
                        working_record['po_name'] = working_record['city'] or working_record['district']
                    if not working_record['district'] or random.random() < 0.1:  # 10% chance to skip district
                        working_record['district'] = working_record['city']
                    
                    # Ensure we have at least some data for the pattern
                    if not working_record['city'] and not working_record['district']:
                        working_record['city'] = working_record['state'] or 'Unknown City'
                    
                    address = pattern.format(**working_record)
                    if address and len(address.strip()) > 5:  # Only add meaningful addresses
                        synthetic_addresses.append((address, clean_record))
                except (KeyError, ValueError) as e:
                    print(f"Warning: Failed to generate address with pattern '{pattern}': {e}")
                    continue
        
        print(f"Generated {len(synthetic_addresses)} synthetic addresses from {len(records)} records")
        return synthetic_addresses
    
    def tokenize_and_align_labels(self, address: str, entities: Dict) -> Tuple[List[str], List[str]]:
        """Tokenize address and create BIO labels."""
        tokens = address.split()
        labels = ['O'] * len(tokens)
        
        # Helper function to find entity in tokens
        def find_entity_positions(entity_text: str, tokens: List[str]) -> List[int]:
            if not entity_text:
                return []
            
            entity_tokens = entity_text.lower().split()
            positions = []
            
            for i in range(len(tokens) - len(entity_tokens) + 1):
                if all(tokens[i + j].lower() == entity_tokens[j] for j in range(len(entity_tokens))):
                    positions.extend(range(i, i + len(entity_tokens)))
                    break
            
            return positions
        
        # Label entities
        entity_mappings = {
            'city': 'CITY',
            'district': 'DISTRICT', 
            'state': 'STATE',
            'po_name': 'PO_NAME'
        }
        
        for entity_key, label_prefix in entity_mappings.items():
            entity_text = entities.get(entity_key, '')
            positions = find_entity_positions(entity_text, tokens)
            
            for i, pos in enumerate(positions):
                if i == 0:
                    labels[pos] = f'B-{label_prefix}'
                else:
                    labels[pos] = f'I-{label_prefix}'
        
        # Handle pincode separately (usually single token)
        pincode = entities.get('pincode', '')
        if pincode:
            for i, token in enumerate(tokens):
                if pincode in token:
                    labels[i] = 'B-PINCODE'
                    break
        
        return tokens, labels
    
    def create_ner_dataset(self, synthetic_addresses: List[Tuple]) -> List[Dict]:
        """Create NER dataset from synthetic addresses."""
        ner_data = []
        
        for address, entities in synthetic_addresses:
            tokens, labels = self.tokenize_and_align_labels(address, entities)
            
            if len(tokens) == len(labels):  # Sanity check
                ner_data.append({
                    'tokens': tokens,
                    'labels': labels,
                    'text': address
                })
        
        return ner_data
    
    def add_noise_to_addresses(self, addresses: List[str], noise_prob: float = 0.1) -> List[str]:
        """Add realistic noise to addresses for robustness."""
        noisy_addresses = []
        
        for address in addresses:
            if random.random() < noise_prob:
                # Add typos
                words = address.split()
                if words:
                    idx = random.randint(0, len(words) - 1)
                    word = words[idx]
                    if len(word) > 2:
                        # Simple character substitution
                        char_idx = random.randint(1, len(word) - 2)
                        word = word[:char_idx] + random.choice('abcdefghijklmnopqrstuvwxyz') + word[char_idx + 1:]
                        words[idx] = word
                        address = ' '.join(words)
            
            noisy_addresses.append(address)
        
        return noisy_addresses
    
    def process_and_split_data(self, data_path: str, test_size: float = 0.2, val_size: float = 0.1) -> Optional[Tuple]:
        """Complete preprocessing pipeline."""
        print("Starting data preprocessing...")
        
        # Load raw data
        raw_data = self.load_data(data_path)
        if not raw_data:
            print("Failed to load data. Please check the file format and encoding.")
            return None
        
        # Generate synthetic addresses
        print("Generating synthetic addresses...")
        synthetic_addresses = self.generate_synthetic_addresses(raw_data, num_samples_per_record=4)
        
        if not synthetic_addresses:
            print("Failed to generate synthetic addresses.")
            return None
        
        # Create NER dataset
        print("Creating NER dataset...")
        ner_dataset = self.create_ner_dataset(synthetic_addresses)
        
        if not ner_dataset:
            print("Failed to create NER dataset.")
            return None
        
        # Split data
        train_data, temp_data = train_test_split(
            ner_dataset, 
            test_size=(test_size + val_size), 
            random_state=TRAIN_CONFIG['random_state']
        )
        
        val_data, test_data = train_test_split(
            temp_data,
            test_size=(test_size / (test_size + val_size)),
            random_state=TRAIN_CONFIG['random_state']
        )
        
        # Save processed data
        try:
            self.save_dataset(train_data, TRAIN_DATA_PATH)
            self.save_dataset(val_data, VAL_DATA_PATH)
            self.save_dataset(test_data, DATA_DIR / "test_data.json")
            
            # Save original data for pincode validation
            with open(DATA_DIR / "pincode_lookup.json", 'w', encoding='utf-8') as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            print(f"Data split complete:")
            print(f"  Train: {len(train_data)} samples")
            print(f"  Validation: {len(val_data)} samples") 
            print(f"  Test: {len(test_data)} samples")
            
            return train_data, val_data, test_data
            
        except Exception as e:
            print(f"Error saving processed data: {e}")
            return None
    
    def save_dataset(self, dataset: List[Dict], file_path: Path):
        """Save dataset to JSON file."""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(dataset, f, indent=2, ensure_ascii=False)
            print(f"Saved {len(dataset)} samples to {file_path}")
        except Exception as e:
            print(f"Error saving dataset to {file_path}: {e}")
            raise
    
    def get_label_distribution(self, dataset: List[Dict]) -> Dict:
        """Analyze label distribution for class balancing."""
        label_counts = {}
        
        for sample in dataset:
            for label in sample['labels']:
                label_counts[label] = label_counts.get(label, 0) + 1
        
        return label_counts

if __name__ == "__main__":
    preprocessor = AddressDataPreprocessor()
    
    # Make sure data directory exists
    DATA_DIR.mkdir(exist_ok=True)
    
    # Process data (assuming data.json is already in data/ directory)
    if DATA_JSON_PATH.exists():
        result = preprocessor.process_and_split_data(str(DATA_JSON_PATH))
        
        if result is not None:
            train_data, val_data, test_data = result
            
            # Print label distribution
            print("\nLabel distribution in training data:")
            label_dist = preprocessor.get_label_distribution(train_data)
            for label, count in sorted(label_dist.items()):
                print(f"  {label}: {count}")
        else:
            print("Data preprocessing failed. Please check the error messages above.")
    else:
        print(f"Please place your data.json file in {DATA_DIR}")