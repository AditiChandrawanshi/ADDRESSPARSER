import json
import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from transformers import AutoTokenizer, AutoModelForTokenClassification
from sklearn.metrics import confusion_matrix, classification_report
from seqeval.metrics import accuracy_score, precision_score, recall_score, f1_score
from seqeval.metrics import classification_report as ner_classification_report
from collections import defaultdict, Counter
import pandas as pd

from config import *
from train import AddressNERDataset

class AddressNEREvaluator:
    def __init__(self, model_path=None):
        self.model_path = model_path or MODEL_SAVE_PATH
        self.tokenizer = None
        self.model = None
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
    def load_model(self):
        """Load trained model and tokenizer."""
        print(f"Loading model from {self.model_path}")
        
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path)
        self.model = AutoModelForTokenClassification.from_pretrained(self.model_path)
        self.model.to(self.device)
        self.model.eval()
        
        print("Model loaded successfully!")
        
    def predict_batch(self, dataset):
        """Make predictions on a dataset."""
        predictions = []
        true_labels = []
        
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=16)
        
        with torch.no_grad():
            for batch in dataloader:
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels']
                
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
                pred_logits = outputs.logits.cpu().numpy()
                pred_labels = np.argmax(pred_logits, axis=2)
                
                # Convert to label names, excluding special tokens
                for i in range(len(pred_labels)):
                    pred_seq = []
                    true_seq = []
                    
                    for j in range(len(pred_labels[i])):
                        if labels[i][j] != -100:  # Not a special token
                            # Convert tensor to integer before using as dictionary key
                            pred_label_id = int(pred_labels[i][j])
                            true_label_id = int(labels[i][j].item())  # .item() converts tensor to Python scalar
                            
                            pred_seq.append(ID_TO_LABEL[pred_label_id])
                            true_seq.append(ID_TO_LABEL[true_label_id])
                    
                    predictions.append(pred_seq)
                    true_labels.append(true_seq)
        
        return predictions, true_labels
    
    def evaluate_model(self, test_data_path=None):
        """Comprehensive model evaluation."""
        if not self.model:
            self.load_model()
        
        # Load test data
        if not test_data_path:
            test_data_path = DATA_DIR / "test_data.json"
        
        print(f"Loading test data from {test_data_path}")
        with open(test_data_path, 'r', encoding='utf-8') as f:
            test_data = json.load(f)
        
        # Create test dataset
        test_dataset = AddressNERDataset(
            test_data, self.tokenizer, MODEL_CONFIG['max_length']
        )
        
        print("Making predictions...")
        predictions, true_labels = self.predict_batch(test_dataset)
        
        # Calculate metrics
        results = self.calculate_metrics(predictions, true_labels)
        
        # Print results
        self.print_evaluation_results(results, predictions, true_labels)
        
        # Generate visualizations
        self.generate_evaluation_plots(predictions, true_labels)
        
        # Analyze errors
        self.analyze_errors(test_data, predictions, true_labels)
        
        return results
    
    def calculate_metrics(self, predictions, true_labels):
        """Calculate comprehensive NER metrics."""
        # Overall metrics
        accuracy = accuracy_score(true_labels, predictions)
        precision = precision_score(true_labels, predictions)
        recall = recall_score(true_labels, predictions)
        f1 = f1_score(true_labels, predictions)
        
        # Per-entity metrics
        entity_results = {}
        
        # Flatten for per-label analysis
        flat_true = [label for seq in true_labels for label in seq]
        flat_pred = [label for seq in predictions for label in seq]
        
        # Entity-wise performance
        for entity in ['CITY', 'DISTRICT', 'STATE', 'PINCODE', 'PO_NAME']:
            entity_true = [1 if label.endswith(entity) else 0 for label in flat_true]
            entity_pred = [1 if label.endswith(entity) else 0 for label in flat_pred]
            
            if sum(entity_true) > 0:  # Only calculate if entity exists
                from sklearn.metrics import precision_score as sk_precision
                from sklearn.metrics import recall_score as sk_recall
                from sklearn.metrics import f1_score as sk_f1
                
                entity_precision = sk_precision(entity_true, entity_pred, zero_division=0)
                entity_recall = sk_recall(entity_true, entity_pred, zero_division=0)
                entity_f1 = sk_f1(entity_true, entity_pred, zero_division=0)
                
                entity_results[entity] = {
                    'precision': entity_precision,
                    'recall': entity_recall,
                    'f1': entity_f1,
                    'support': sum(entity_true)
                }
        
        return {
            'overall': {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1': f1
            },
            'per_entity': entity_results
        }
    
    def print_evaluation_results(self, results, predictions, true_labels):
        """Print detailed evaluation results."""
        print("\n" + "="*60)
        print("ADDRESS NER MODEL EVALUATION RESULTS")
        print("="*60)
        
        # Overall metrics
        overall = results['overall']
        print(f"\nOVERALL PERFORMANCE:")
        print(f"  Accuracy:  {overall['accuracy']:.4f}")
        print(f"  Precision: {overall['precision']:.4f}")
        print(f"  Recall:    {overall['recall']:.4f}")
        print(f"  F1-Score:  {overall['f1']:.4f}")
        
        # Per-entity metrics
        print(f"\nPER-ENTITY PERFORMANCE:")
        print(f"{'Entity':<12} {'Precision':<10} {'Recall':<10} {'F1-Score':<10} {'Support':<8}")
        print("-" * 55)
        
        for entity, metrics in results['per_entity'].items():
            print(f"{entity:<12} {metrics['precision']:<10.4f} {metrics['recall']:<10.4f} "
                  f"{metrics['f1']:<10.4f} {metrics['support']:<8}")
        
        # Detailed classification report
        print(f"\nDETAILED CLASSIFICATION REPORT:")
        print(ner_classification_report(true_labels, predictions))
    
    def generate_evaluation_plots(self, predictions, true_labels):
        """Generate evaluation visualizations."""
        print("\nGenerating evaluation plots...")
        
        # Create plots directory
        plots_dir = MODELS_DIR / "evaluation_plots"
        plots_dir.mkdir(exist_ok=True)
        
        # 1. Entity distribution plot
        self.plot_entity_distribution(true_labels, predictions, plots_dir)
        
        # 2. Confusion matrix for each entity type
        self.plot_confusion_matrices(true_labels, predictions, plots_dir)
        
        # 3. F1 scores by entity
        self.plot_entity_f1_scores(true_labels, predictions, plots_dir)
    
    def plot_entity_distribution(self, true_labels, predictions, save_dir):
        """Plot distribution of entities in true vs predicted labels."""
        # Count entities
        true_entities = defaultdict(int)
        pred_entities = defaultdict(int)
        
        for seq in true_labels:
            for label in seq:
                if label != 'O':
                    entity = label.split('-')[1] if '-' in label else label
                    true_entities[entity] += 1
        
        for seq in predictions:
            for label in seq:
                if label != 'O':
                    entity = label.split('-')[1] if '-' in label else label
                    pred_entities[entity] += 1
        
        # Create plot
        entities = list(set(list(true_entities.keys()) + list(pred_entities.keys())))
        true_counts = [true_entities[e] for e in entities]
        pred_counts = [pred_entities[e] for e in entities]
        
        x = np.arange(len(entities))
        width = 0.35
        
        plt.figure(figsize=(10, 6))
        plt.bar(x - width/2, true_counts, width, label='True', alpha=0.8)
        plt.bar(x + width/2, pred_counts, width, label='Predicted', alpha=0.8)
        
        plt.xlabel('Entity Types')
        plt.ylabel('Count')
        plt.title('Entity Distribution: True vs Predicted')
        plt.xticks(x, entities, rotation=45)
        plt.legend()
        plt.tight_layout()
        plt.savefig(save_dir / 'entity_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_confusion_matrices(self, true_labels, predictions, save_dir):
        """Plot confusion matrix for each entity type."""
        entities = ['CITY', 'DISTRICT', 'STATE', 'PINCODE', 'PO_NAME']
        
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        axes = axes.flatten()
        
        for i, entity in enumerate(entities):
            # Create binary labels for this entity
            true_binary = []
            pred_binary = []
            
            for true_seq, pred_seq in zip(true_labels, predictions):
                for true_label, pred_label in zip(true_seq, pred_seq):
                    true_binary.append(1 if entity in true_label else 0)
                    pred_binary.append(1 if entity in pred_label else 0)
            
            # Create confusion matrix
            cm = confusion_matrix(true_binary, pred_binary)
            
            # Plot
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[i])
            axes[i].set_title(f'{entity} Confusion Matrix')
            axes[i].set_xlabel('Predicted')
            axes[i].set_ylabel('True')
        
        # Hide the last subplot if we have fewer entities than subplots
        if len(entities) < len(axes):
            axes[-1].set_visible(False)
        
        plt.tight_layout()
        plt.savefig(save_dir / 'confusion_matrices.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_entity_f1_scores(self, true_labels, predictions, save_dir):
        """Plot F1 scores for each entity type."""
        entities = ['CITY', 'DISTRICT', 'STATE', 'PINCODE', 'PO_NAME']
        f1_scores = []
        
        for entity in entities:
            # Calculate F1 for this entity
            true_binary = []
            pred_binary = []
            
            for true_seq, pred_seq in zip(true_labels, predictions):
                for true_label, pred_label in zip(true_seq, pred_seq):
                    true_binary.append(1 if entity in true_label else 0)
                    pred_binary.append(1 if entity in pred_label else 0)
            
            if sum(true_binary) > 0:
                from sklearn.metrics import f1_score
                f1 = f1_score(true_binary, pred_binary, zero_division=0)
                f1_scores.append(f1)
            else:
                f1_scores.append(0)
        
        # Create plot
        plt.figure(figsize=(10, 6))
        bars = plt.bar(entities, f1_scores, color='skyblue', alpha=0.8)
        plt.xlabel('Entity Types')
        plt.ylabel('F1 Score')
        plt.title('F1 Scores by Entity Type')
        plt.ylim(0, 1)
        
        # Add value labels on bars
        for bar, score in zip(bars, f1_scores):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{score:.3f}', ha='center', va='bottom')
        
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(save_dir / 'f1_scores_by_entity.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def analyze_errors(self, test_data, predictions, true_labels):
        """Analyze prediction errors for insights."""
        print("\nERROR ANALYSIS:")
        print("-" * 40)
        
        errors = []
        
        for i, (data_point, pred_seq, true_seq) in enumerate(zip(test_data, predictions, true_labels)):
            if pred_seq != true_seq:
                errors.append({
                    'index': i,
                    'text': data_point['text'],
                    'tokens': data_point['tokens'],
                    'true_labels': true_seq,
                    'predicted_labels': pred_seq
                })
        
        print(f"Total prediction errors: {len(errors)} out of {len(test_data)} samples")
        print(f"Error rate: {len(errors)/len(test_data)*100:.2f}%")
        
        # Show some example errors
        print(f"\nSample errors (showing first 5):")
        for i, error in enumerate(errors[:5]):
            print(f"\nError {i+1}:")
            print(f"  Text: {error['text']}")
            print(f"  Tokens: {' '.join(error['tokens'])}")
            print(f"  True:      {' '.join(error['true_labels'])}")
            print(f"  Predicted: {' '.join(error['predicted_labels'])}")
        
        # Common error patterns
        error_patterns = defaultdict(int)
        
        for error in errors:
            for true_label, pred_label in zip(error['true_labels'], error['predicted_labels']):
                if true_label != pred_label:
                    pattern = f"{true_label} -> {pred_label}"
                    error_patterns[pattern] += 1
        
        print(f"\nMost common error patterns:")
        for pattern, count in sorted(error_patterns.items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"  {pattern}: {count} times")
        
        return errors
    
    def benchmark_inference_speed(self):
        """Benchmark model inference speed."""
        if not self.model:
            self.load_model()
        
        # Create sample data for benchmarking
        sample_texts = [
            "Bhopal GPO, Bhopal, Madhya Pradesh 462001",
            "Delhi Cantt, New Delhi, Delhi - 110010",
            "Koramangala Post Office, Bangalore, Karnataka 560034"
        ] * 100  # 300 samples
        
        import time
        
        print("\nBenchmarking inference speed...")
        
        start_time = time.time()
        
        for text in sample_texts:
            tokens = text.split()
            inputs = self.tokenizer(
                tokens,
                is_split_into_words=True,
                padding='max_length',
                truncation=True,
                max_length=MODEL_CONFIG['max_length'],
                return_tensors='pt'
            ).to(self.device)
            
            with torch.no_grad():
                _ = self.model(**inputs)
        
        end_time = time.time()
        
        total_time = end_time - start_time
        avg_time_per_sample = total_time / len(sample_texts)
        
        print(f"  Total time: {total_time:.2f} seconds")
        print(f"  Average time per sample: {avg_time_per_sample*1000:.2f} ms")
        print(f"  Throughput: {len(sample_texts)/total_time:.1f} samples/second")

if __name__ == "__main__":
    # Check if model exists
    if not MODEL_SAVE_PATH.exists():
        print("Trained model not found. Please train the model first:")
        print("python src/train.py")
        exit(1)
    
    # Check if test data exists
    test_data_path = DATA_DIR / "test_data.json"
    if not test_data_path.exists():
        print("Test data not found. Please run preprocessing first:")
        print("python src/preprocess.py")
        exit(1)
    
    # Initialize evaluator
    evaluator = AddressNEREvaluator()
    
    print("Starting Address NER Model Evaluation...")
    print("-" * 50)
    
    # Run evaluation
    results = evaluator.evaluate_model()
    
    # Benchmark speed
    evaluator.benchmark_inference_speed()
    
    print("\nEvaluation completed successfully!")
    print(f"Results and plots saved in: {MODELS_DIR}/evaluation_plots/")