import json
import re
from typing import Dict, List, Tuple, Optional
from difflib import SequenceMatcher
from collections import defaultdict
import pandas as pd

from config import *

class PincodeValidator:
    def __init__(self, data_path=None):
        self.data_path = data_path or (DATA_DIR / "pincode_lookup.json")
        self.pincode_data = {}
        self.city_to_pincodes = defaultdict(list)
        self.state_to_pincodes = defaultdict(list)
        self.district_to_pincodes = defaultdict(list)
        self.load_pincode_data()
    
    def load_pincode_data(self):
        """Load and index pincode data for fast lookups."""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            print(f"Loading {len(data)} pincode records...")
            
            for record in data:
                pincode = str(record.get('Pincode', '')).strip()
                city = record.get('City', '').strip().lower()
                district = record.get('District', '').strip().lower()
                state = record.get('State', '').strip().lower()
                po_name = record.get('PostOfficeName', '').strip().lower()
                
                if pincode and len(pincode) == 6 and pincode.isdigit():
                    # Main pincode lookup
                    self.pincode_data[pincode] = {
                        'PostOfficeName': record.get('PostOfficeName', ''),
                        'City': record.get('City', ''),
                        'District': record.get('District', ''),
                        'State': record.get('State', ''),
                        'Pincode': pincode
                    }
                    
                    # Create reverse indexes for validation
                    if city:
                        self.city_to_pincodes[city].append(pincode)
                    if district:
                        self.district_to_pincodes[district].append(pincode)
                    if state:
                        self.state_to_pincodes[state].append(pincode)
            
            print(f"Loaded {len(self.pincode_data)} valid pincodes")
            
        except Exception as e:
            print(f"Error loading pincode data: {e}")
    
    def validate_pincode(self, pincode: str) -> Tuple[bool, Optional[Dict]]:
        """Validate if pincode exists and return associated data."""
        if not pincode:
            return False, None
        
        # Clean pincode
        clean_pincode = re.sub(r'[^\d]', '', str(pincode))
        
        if len(clean_pincode) != 6:
            return False, None
        
        if clean_pincode in self.pincode_data:
            return True, self.pincode_data[clean_pincode]
        
        return False, None
    
    def find_similar_pincodes(self, pincode: str, max_distance: int = 1) -> List[Tuple[str, Dict]]:
        """Find pincodes similar to the given one (for typo correction)."""
        if not pincode:
            return []
        
        clean_pincode = re.sub(r'[^\d]', '', str(pincode))
        if len(clean_pincode) != 6:
            return []
        
        similar_pincodes = []
        
        for valid_pincode, data in self.pincode_data.items():
            # Calculate Hamming distance for fixed-length strings
            distance = sum(c1 != c2 for c1, c2 in zip(clean_pincode, valid_pincode))
            if distance <= max_distance and distance > 0:
                similar_pincodes.append((valid_pincode, data))
        
        return similar_pincodes[:5]  # Return top 5 matches
    
    def validate_consistency(self, extracted_data: Dict) -> Dict:
        """Validate consistency between extracted entities."""
        result = {
            'is_consistent': True,
            'issues': [],
            'suggestions': {},
            'confidence': 1.0
        }
        
        pincode = extracted_data.get('Pincode', '')
        city = extracted_data.get('City', '').lower().strip()
        district = extracted_data.get('District', '').lower().strip()
        state = extracted_data.get('State', '').lower().strip()
        
        # Validate pincode first
        is_valid, pincode_data = self.validate_pincode(pincode)
        
        if not is_valid:
            result['is_consistent'] = False
            result['issues'].append(f"Invalid pincode: {pincode}")
            result['confidence'] *= 0.3
            
            # Try to find similar pincodes
            similar = self.find_similar_pincodes(pincode)
            if similar:
                result['suggestions']['pincode'] = [
                    {'pincode': p, 'location': f"{d['City']}, {d['State']}"} 
                    for p, d in similar
                ]
            
            return result
        
        # If pincode is valid, check consistency with other fields
        expected_city = pincode_data['City'].lower().strip()
        expected_district = pincode_data['District'].lower().strip()
        expected_state = pincode_data['State'].lower().strip()
        
        # Check city consistency
        if city and self.similarity_score(city, expected_city) < VALIDATION_CONFIG['similarity_threshold']:
            result['is_consistent'] = False
            result['issues'].append(f"City mismatch: '{city}' vs expected '{expected_city}'")
            result['suggestions']['city'] = expected_city
            result['confidence'] *= 0.7
        
        # Check district consistency
        if district and self.similarity_score(district, expected_district) < VALIDATION_CONFIG['similarity_threshold']:
            result['is_consistent'] = False
            result['issues'].append(f"District mismatch: '{district}' vs expected '{expected_district}'")
            result['suggestions']['district'] = expected_district
            result['confidence'] *= 0.8
        
        # Check state consistency
        if state and self.similarity_score(state, expected_state) < VALIDATION_CONFIG['similarity_threshold']:
            result['is_consistent'] = False
            result['issues'].append(f"State mismatch: '{state}' vs expected '{expected_state}'")
            result['suggestions']['state'] = expected_state
            result['confidence'] *= 0.5
        
        return result
    
    def similarity_score(self, str1: str, str2: str) -> float:
        """Calculate similarity between two strings."""
        if not str1 or not str2:
            return 0.0
        
        return SequenceMatcher(None, str1.lower(), str2.lower()).ratio()
    
    def correct_address(self, extracted_data: Dict) -> Dict:
        """Attempt to correct address based on pincode validation."""
        corrected_data = extracted_data.copy()
        validation_result = self.validate_consistency(extracted_data)
        
        if not validation_result['is_consistent']:
            pincode = extracted_data.get('Pincode', '')
            is_valid, pincode_data = self.validate_pincode(pincode)
            
            if is_valid:
                # Use pincode data to fill/correct other fields
                corrected_data['City'] = pincode_data['City']
                corrected_data['District'] = pincode_data['District']
                corrected_data['State'] = pincode_data['State']
                corrected_data['PostOfficeName'] = pincode_data['PostOfficeName']
                corrected_data['_corrected'] = True
                corrected_data['_original'] = extracted_data.copy()
        
        return corrected_data
    
    def find_pincodes_by_location(self, city: str = None, district: str = None, state: str = None) -> List[str]:
        """Find pincodes for a given location."""
        pincodes = set()
        
        if city:
            city_key = city.lower().strip()
            pincodes.update(self.city_to_pincodes.get(city_key, []))
        
        if district:
            district_key = district.lower().strip()
            district_pincodes = set(self.district_to_pincodes.get(district_key, []))
            if pincodes:
                pincodes = pincodes.intersection(district_pincodes)
            else:
                pincodes = district_pincodes
        
        if state:
            state_key = state.lower().strip()
            state_pincodes = set(self.state_to_pincodes.get(state_key, []))
            if pincodes:
                pincodes = pincodes.intersection(state_pincodes)
            else:
                pincodes = state_pincodes
        
        return sorted(list(pincodes))
    
    def suggest_pincode(self, extracted_data: Dict) -> List[Dict]:
        """Suggest possible pincodes based on extracted location data."""
        city = extracted_data.get('City', '')
        district = extracted_data.get('District', '')
        state = extracted_data.get('State', '')
        
        # Find pincodes for the location
        possible_pincodes = self.find_pincodes_by_location(city, district, state)
        
        suggestions = []
        for pincode in possible_pincodes[:10]:  # Limit to top 10
            pincode_info = self.pincode_data.get(pincode, {})
            suggestions.append({
                'pincode': pincode,
                'post_office': pincode_info.get('PostOfficeName', ''),
                'city': pincode_info.get('City', ''),
                'district': pincode_info.get('District', ''),
                'state': pincode_info.get('State', ''),
                'match_score': self.calculate_match_score(extracted_data, pincode_info)
            })
        
        # Sort by match score
        suggestions.sort(key=lambda x: x['match_score'], reverse=True)
        
        return suggestions
    
    def calculate_match_score(self, extracted: Dict, pincode_data: Dict) -> float:
        """Calculate how well extracted data matches pincode data."""
        score = 0.0
        total_weight = 0.0
        
        # Weights for different fields
        weights = {
            'City': 0.3,
            'District': 0.25,
            'State': 0.35,
            'PostOfficeName': 0.1
        }
        
        for field, weight in weights.items():
            extracted_value = extracted.get(field, '').lower().strip()
            pincode_value = pincode_data.get(field, '').lower().strip()
            
            if extracted_value and pincode_value:
                similarity = self.similarity_score(extracted_value, pincode_value)
                score += similarity * weight
                total_weight += weight
        
        return score / total_weight if total_weight > 0 else 0.0
    
    def get_statistics(self) -> Dict:
        """Get statistics about the pincode database."""
        stats = {
            'total_pincodes': len(self.pincode_data),
            'unique_cities': len(self.city_to_pincodes),
            'unique_districts': len(self.district_to_pincodes),
            'unique_states': len(self.state_to_pincodes)
        }
        
        # State-wise distribution
        state_distribution = {}
        for state, pincodes in self.state_to_pincodes.items():
            state_distribution[state.title()] = len(pincodes)
        
        stats['state_distribution'] = dict(sorted(
            state_distribution.items(), 
            key=lambda x: x[1], 
            reverse=True
        ))
        
        return stats

# Example usage and testing
if __name__ == "__main__":
    # Initialize validator
    validator = PincodeValidator()
    
    # Print statistics
    stats = validator.get_statistics()
    print("Pincode Database Statistics:")
    print(f"  Total pincodes: {stats['total_pincodes']}")
    print(f"  Unique cities: {stats['unique_cities']}")
    print(f"  Unique districts: {stats['unique_districts']}")
    print(f"  Unique states: {stats['unique_states']}")
    
    # Test validation
    test_cases = [
        {
            'Pincode': '462001',
            'City': 'Bhopal',
            'District': 'Bhopal',
            'State': 'Madhya Pradesh'
        },
        {
            'Pincode': '110001', 
            'City': 'Delhi',
            'District': 'Central Delhi',
            'State': 'Delhi'
        },
        {
            'Pincode': '462001',
            'City': 'Mumbai',  # Wrong city
            'District': 'Bhopal',
            'State': 'Madhya Pradesh'
        }
    ]
    
    print("\nValidation Tests:")
    for i, test_case in enumerate(test_cases):
        print(f"\nTest {i+1}: {test_case}")
        validation_result = validator.validate_consistency(test_case)
        print(f"  Consistent: {validation_result['is_consistent']}")
        print(f"  Confidence: {validation_result['confidence']:.2f}")
        if validation_result['issues']:
            print(f"  Issues: {validation_result['issues']}")
        if validation_result['suggestions']:
            print(f"  Suggestions: {validation_result['suggestions']}")